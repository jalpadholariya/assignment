export interface Iinvestment {
  Id: number;
  Investment1: string;
  CommitmentDate: string;
  MarketValue: number;
}
