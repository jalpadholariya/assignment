import {Injectable} from '@angular/core';
import {Iinvestment} from './model/iinvestment';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {stringify} from 'querystring';
import {map} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class InvestmentService {
  private apiPrefix: string;

  constructor(private http: HttpClient) {
    this.apiPrefix = 'http://localhost:64038/api/investment/';
  }

  static createUrlQuery(params: any) {
    if (!params) {
      return '';
    }

    let page;
    let perPage;
    let field;
    let order;
    const query: any = {};
    if (params.pagination) {
      page = params.pagination.page;
      perPage = params.pagination.perPage;
      query.range = JSON.stringify([
        page,
        perPage,
      ]);
    }
    if (params.sort) {
      field = params.sort.field;
      order = params.sort.order;
      if (field && order) {
        query.sort = JSON.stringify([field, order]);
      } else {
        query.sort = JSON.stringify(['Id', 'ASC']);
      }
    }
    if (!params.filter) {
      params.filter = {};
    }
    if (Array.isArray(params.ids)) {
      params.filter.id = params.ids;
    }

    if (params.filter) {
      query.filter = JSON.stringify(params.filter);
    }
    console.log(query, stringify(query));
    return stringify(query);
  }


  // tslint:disable-next-line:ban-types
  public fetchLatest(sort: string = '', order: string = '', page: number = 1, perPage: number = 5, initTotal: Function = () => {
  }): Observable<Iinvestment[]> {
    /*return this.http.post<Iinvestment[]>(this.apiPrefix + 'GetRecords' + '?' + InvestmentService.createUrlQuery({
      sort: {field: sort, order},
      pagination: {page, perPage}
    }), null);*/

    const filterOptions = {
      StartRow: 0,
      EndRow: 5,
      SortColumn: sort,
      SortOrder: order,
    };

    return this.http.post<Iinvestment[]>(this.apiPrefix + 'FilterRecords', filterOptions)
      .pipe(map((res: any) => {
        const total = res.totalCount;
        initTotal(total);
        return res.data;
      }));

  }

  public getRecords(params: any): Observable<Iinvestment[]> {

    const filters = Object.keys(params.filterModel).map(p => {
      const filter = {};
      filter[p] = params.filterModel[p].filter;
      return filter;
    });

    const filterOptions = {
      StartRow: params.startRow,
      EndRow: params.endRow,
      SortColumn: params.sortModel.length > 0 ? params.sortModel[0].colId : null,
      SortOrder: params.sortModel.length > 0 ? params.sortModel[0].sort : 'asc',
      Filters: filters
    };

    return this.http.post<Iinvestment[]>(this.apiPrefix + 'FilterRecords', filterOptions);

  }
}
