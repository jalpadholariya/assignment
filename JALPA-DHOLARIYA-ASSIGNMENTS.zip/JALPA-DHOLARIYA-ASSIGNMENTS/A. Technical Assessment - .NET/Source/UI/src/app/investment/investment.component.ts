import {Component} from '@angular/core';
import {InvestmentService} from '../investment.service';
import {HttpClient} from '@angular/common/http';
import {AllModules} from '@ag-grid-enterprise/all-modules';
import {IDatasource, IGetRowsParams} from 'ag-grid-community';


@Component({
  selector: 'app-investment',
  templateUrl: './investment.component.html',
  styleUrls: ['./investment.component.css']
})
export class InvestmentComponent {


  private gridApi;
  private gridColumnApi;
  // @ts-ignore
  public modules: Module[] = AllModules;

  private columnDefs;
  private defaultColDef;
  private rowModelType;
  private cacheBlockSize;
  private maxBlocksInCache;
  private paginationPageSize;
  private rowData: [];
  private dataSource: IDatasource;

  constructor(private http: HttpClient, private entityService: InvestmentService) {
    this.columnDefs = [
      // {field: 'id', width: 60},
      {headerName: 'Investment', field: 'Investment1', width: 200, filter: 'agTextColumnFilter'},
      {
        headerName: 'Commitment Date',
        field: 'CommitmentDateStr', width: 200,
        filter: 'agTextColumnFilter'
        /* filter: 'agDateColumnFilter',
         filterOptions: ['equals'],
         suppressAndOrCondition: true,
         newRowsAction: 'keep'
         filterParams: {
           comparator(filterLocalDateAtMidnight, cellValue) {
             const dateAsString = cellValue;
             const dateParts = dateAsString.split('/');
             const cellDate = new Date(Number(dateParts[2]), Number(dateParts[1]) - 1, Number(dateParts[0]));
             if (filterLocalDateAtMidnight.getTime() === cellDate.getTime()) {
               return 0;
             }
             if (cellDate < filterLocalDateAtMidnight) {
               return -1;
             }
             if (cellDate > filterLocalDateAtMidnight) {
               return 1;
             }
           }
         }*/
      },
      {field: 'MarketValue', filter: 'agNumberColumnFilter'}
    ];
    this.defaultColDef = {
      width: 150,
      resizable: true,
      sortable: true,
      // filter: true,
      // enableValue: true,
      // enableRowGroup: true,
      // enablePivot: true,
      floatingFilter: true
    };
    this.dataSource = {
      getRows: (params: IGetRowsParams) => {

        // Use startRow and endRow for sending pagination to Backend
        // params.startRow : Start Page
        // params.endRow : End Page

        console.log('params:', params);

        // replace this.apiService with your Backend Call that returns an Observable
        this.entityService.getRecords(params).subscribe((response: any) => {
          params.successCallback(
            response.data,
            response.totalRecords
          );
        });
      }
    };
    this.paginationPageSize = 10;
    // this.rowModelType = 'serverSide';
    this.rowModelType = 'infinite';
    // Can increase to avoid server trip on each page.. like 100, 500
    this.cacheBlockSize = 10;
    this.maxBlocksInCache = 10;
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridApi.setDatasource(this.dataSource);
    this.gridApi.paginationSetPageSize(10);
  }


}

