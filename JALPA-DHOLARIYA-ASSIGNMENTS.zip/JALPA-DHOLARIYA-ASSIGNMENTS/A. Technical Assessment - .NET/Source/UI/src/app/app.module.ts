import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';

import {AppRoutingModule} from './app-routing.module';
import {AppComponent} from './app.component';
import {AngularmaterialModule} from './material/angularmaterial/angularmaterial.module';
import {InvestmentService} from './investment.service';
import {HttpClientModule} from '@angular/common/http';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {InvestmentComponent} from './investment/investment.component';
import {AgGridModule} from 'ag-grid-angular';

@NgModule({
  declarations: [
    AppComponent,
    InvestmentComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    BrowserAnimationsModule,
    AngularmaterialModule,
    AppRoutingModule,
    AgGridModule.withComponents([])
  ],
  providers: [InvestmentService],
  bootstrap: [AppComponent]
})
export class AppModule {
}
