﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Web.Http;
using System.Web.Http.Cors;
using Newtonsoft.Json;
using WebAPI.Models;
using System.Linq.Dynamic;

namespace WebAPI.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    [RoutePrefix("api/investment")]
    public class InvestmentController : ApiController
    {
        GIC_TESTEntities _context;

        public InvestmentController()
        {
            _context = new GIC_TESTEntities();
        }

        // Using POST here, instead of GET because of dynamic filter params
        [HttpPost]
        [Route("FilterRecords")]
        public IHttpActionResult UserDetails(RequestInvestmentsParams investmentsParams)
        {
            IEnumerable<ResponseInvestment> lstUser = new List<ResponseInvestment>();
            var count = 0;
            try
            {
                // var sourceQuery = (from investment in _context.Investments select investment);
                var sourceQuery = (from investment in _context.Investments.AsEnumerable() select new ResponseInvestment()
                {
                    Id = investment.Id,
                    CommitmentDate = investment.CommitmentDate,
                    MarketValue = investment.MarketValue,
                    Investment1 = investment.Investment1,
                    CommitmentDateStr = investment.CommitmentDate.ToString("yyyy-MM-dd HH:mm")
                });

                if (investmentsParams.Filters != null)
                {
                  
                    foreach (var dictionary in investmentsParams.Filters)
                    {
                        var allFilters = (Dictionary<string, string>) dictionary;
                        foreach(var kvp in allFilters)
                        {
                            var column = kvp.Key;
                            var searchValue = kvp.Value.ToLower();

                            switch (column)
                            {
                                case "Investment1":
                                    sourceQuery = sourceQuery.Where(x => x.Investment1.ToLower().Contains(searchValue));
                                    break;
                                case "CommitmentDateStr":
                                    sourceQuery = sourceQuery.Where(x =>
                                        x.CommitmentDateStr.Contains(searchValue));
                                    break;
                                case "MarketValue":
                                    sourceQuery = sourceQuery.Where(x =>
                                        x.MarketValue.ToString().ToLower().Contains(searchValue));
                                    break;
                            }
                        }
                    }
                    
                }
                
                if (!string.IsNullOrEmpty(investmentsParams.SortColumn))
                {
                    

                    
                    if (!string.IsNullOrEmpty(investmentsParams.SortOrder) &&
                        investmentsParams.SortOrder.ToLower() == "desc")
                    {
                        // sourceQuery = sourceQuery.OrderByDescending(sortExpression);
                        sourceQuery = sourceQuery.OrderBy(investmentsParams.SortColumn + " DESC");
                    }
                    else
                    {
                        sourceQuery = sourceQuery.OrderBy(investmentsParams.SortColumn);
                    }
                }
                else
                {
                    sourceQuery = sourceQuery.OrderBy(x => x.Id);
                }

                var source = sourceQuery.AsQueryable();

                count = source.Count();

                lstUser = source.Skip(investmentsParams.StartRow)
                    .Take(investmentsParams.EndRow - investmentsParams.StartRow).ToList();
            }
            catch (Exception ex)
            {
                Console.Write(ex.ToString());
            }

            var result = new
            {
                data = lstUser,
                totalCount = count,
                // pageSize = PageSize,  
                // currentPage = CurrentPage,  
                // totalPages = TotalPages
            };

            var response = this.Request.CreateResponse(HttpStatusCode.OK);
            response.Content =
                new StringContent(JsonConvert.SerializeObject(result), Encoding.UTF8, "application/json");
            return ResponseMessage(response);
        }
    }

    public class RequestInvestmentsParams
    {
        public int StartRow;
        public int EndRow;


        // if filtering, what the filter model is
        public List<IDictionary<string, string>> Filters;

        // if sorting, what the sort model is
        public string SortColumn;
        public string SortOrder;
    }
}